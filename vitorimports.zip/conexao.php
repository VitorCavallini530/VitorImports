<?php
$servidor = "127.0.0.1:50344";
$usuario = "azure";
$senha = "6#vWHD_$";
$dbname = "camisetas";

//Criar a conexao
$conn = mysqli_connect($servidor, $usuario, $senha, $dbname);