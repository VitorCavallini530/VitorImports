<?php

//Credenciais de acesso ao BD
define('HOST', '127.0.0.1:50344');
define('USER', 'azure');
define('PASS', '6#vWHD_$');
define('DBNAME', 'camisetas');

$connect = new PDO('mysql:host=' . HOST . ';dbname=' . DBNAME . ';', USER, PASS); 

